"""market URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from predict import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.start, name='start'),   #首先加载动画

    #path('',views.login_c,name='login'),
    path('login/',views.login_c,name='login'),
    #path('',views.signup,name='signup'),
    path('signup/',views.signup,name='signup'),
    path('logoutuser/',views.logoutuser,name='logoutuser'),
    #path('',views.logout,name='logout'),

    path('index/', views.index, name='index'),   #之后加载网页
    path('', views.icon, name='icon'),
    path('', views.maps, name='maps'),
    path('', views.notifications, name='notifications'),
    path('table/', views.table, name='table'),
    path('', views.template, name='template'),
    path('', views.typography, name='typography'),
    path('', views.upgrade, name='upgrade'),
    path('', views.account, name='account'),
    path('cloud/', views.cloud, name='cloud'),
    path('item_recommend/', views.item_recommend, name='item_recommend'),
    path('sender_mail/', views.sender_mail, name='sender_mail'),
    path('upload_file/', views.upload_file, name='upload_file'),
    path('predict_file/', views.predict_file, name='predict_file')

]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.TEMPLATES_ROOT)
