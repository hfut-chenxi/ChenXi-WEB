from __future__ import unicode_literals
from django.shortcuts import render,redirect
from django.http import HttpResponse


from django.contrib import messages

from django.contrib import auth
from django.contrib.auth.models import auth
from django.contrib.auth import authenticate, logout
from django.contrib.auth import login
from django.contrib.auth.models import User
#from backend.models import *
from django.contrib.auth.decorators import login_required

import pandas as pd
import numpy as np

import smtplib
from email import (header)
from email.mime import (text, application, multipart)
import time



import random
import joblib
import sys
#sys.modules['sklearn.externals.joblib'] = joblib

from sklearn.metrics import accuracy_score
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import accuracy_score
from matplotlib import pyplot as plt
from collections import Counter
import json
from django.shortcuts import render
import PIL.Image as image
from wordcloud import WordCloud


plt.rcParams['font.sans-serif'] = ['SimHei']
from django.conf import settings
import os
import base64

FILE_PATH = ""
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def PCA_process(data, n):
    """
    主成分分析，作为五监督式学习，可对数据进行预处理，然后降低监督式学习的计算复杂度以及提高精准度

    data: 原始数据
    n: 选择的主成分个数
    Returns
    -------
    PCA后的X数据

    """
    max_cols, max_rows = data.shape
    max_cols = max_cols - 2  # 对于该数据集，第一列用户ID和最后一列RESP不作为训练数据
    # 这里尝试进行Standard放缩法
    X = data.iloc[:, 2:max_cols]
    scaler = StandardScaler()
    scaler.fit(X)
    X_scaled = scaler.transform(X)
    pca = PCA(n_components=n)
    pca.fit(X_scaled)
    X_pca = pca.transform(X_scaled)

    # 上面n_components就是主成分的个数，分为2个,所以现在数据X的形状变为(28798, 46)
    # 下面对两个主成分包含的信息进行可视化
    """
    plt.matshow(pca.components_, cmap='viridis')
    plt.yticks([0, 1], ['First component', 'second somponent'])
    plt.colorbar()
    plt.xticks(range(2, max_cols), ['{}'.format(i) for i in range(2, max_cols)], ha='left')
    plt.xlabel("Feature")
    plt.ylabel("Principal label")
    plt.show()
    """
    return X_pca


def k_means(X, n, predict_path):
    """
    1、将数据进行K-means聚类，将聚类结果(返回一个列表)作为新的一列加到PCA之后的X中
    2、根据聚类结果绘制图表，并将其保存到本地
    """
    predict_path = predict_path.split('_')[0] + '_sse.png'
    # 画出SSE的评估图
    sse = []
    for i in range(2, 11):
        clf = KMeans(n_clusters=i)
        clf.fit(X)
        sse.append(clf.inertia_)

    print(len(sse))
    print(sse)
    plt.figure(figsize=(10, 6))
    plt.plot(range(2, 11), sse, marker='o')
    plt.xlabel('k')
    plt.ylabel('SSE')
    plt.savefig(predict_path)

    clf = KMeans(n_clusters=n)
    clf.fit(X)
    label = clf.labels_
    print("label的形状: {}".format(label.shape))

    predict_path2 = predict_path.split('_')[0] + '_类别.png'

    # 可以为类别画画饼状图
    class_ = []
    for i in range(n):
        class_.append(str(i))
    count_ = np.bincount(label)
    plt.pie(count_, labels=class_, shadow=True, autopct='%1.1f%%')  # 最后一个参数可以计算比例
    plt.title('类别占比')
    plt.savefig(predict_path2)
    return label


def plot_analysis(data):
    """
    input: 要预测的原始数据
    这里的数据首先是没有把时间分割成月、日、小时
    """
    table = pd.pivot_table(data, index=['behavior_type', 'time'], values=['user_id'], aggfunc='count')

    # 点击事件的事件序列统计
    click = table.xs(1, level='behavior_type')
    click_time = list(click.index)
    click_counts = list(click.iloc[:, 0])

    # 收藏事件的时间序列统计
    collect = table.xs(2, level='behavior_type')
    collect_time = list(collect.index)
    collect_counts = list(collect.iloc[:, 0])

    # 加购物车事件的时间序列统计
    push = table.xs(3, level='behavior_type')
    push_time = list(push.index)
    push_counts = list(push.iloc[:, 0])

    # 购买事件的时间序列统计
    buy = table.xs(4, level='behavior_type')
    buy_time = list(buy.index)
    buy_counts = list(buy.iloc[:, 0])

    table = np.array(table.reset_index())
    time_info = list(table[table[:, 0] == 1][:, 1])

    # 将所有以上数据合并到numpy array中
    Info = [time_info, click_counts, collect_counts, push_counts, buy_counts]

    return Info


def data_process(data):
    d = data.pop('behavior_type')
    data.pop("user_geohash")
    data['behavior_type'] = d
    X = pd.pivot_table(data, index=['user_id', 'item_id', 'item_category', 'time'],
                       values=['behavior_type'], aggfunc='max')
    X = X.reset_index()
    X['time'] = pd.to_datetime(X['time'])

    # 分解得出月份
    times = X['time'].dt.strftime('%m')
    month = [int(i) for i in times]

    # 分解得出日
    times = X['time'].dt.strftime('%d')
    date = [int(i) for i in times]

    # 分解得出小时
    times = X['time'].dt.strftime('%H')
    hour = [int(i) for i in times]

    X.pop('time')   # 删除time这一列
    X['month'] = month  # 把分解后的月、日、小时添加进来
    X['date'] = date
    X['hour'] = hour

    # 调整列的顺序
    d = X.pop('behavior_type')
    X['behavior_type'] = d
    d = 0  # 不知道这样能不能节省内存
    return X


def predict(filename):
    predict_path = filename.split('_')[0] + "_predict" + ".xlsx"
    print(filename)
    print(predict_path)
    data = pd.read_excel(filename)

    # 2、删除不必要的特征
    data.drop('HHKEY', axis=1, inplace=True)
    data.drop('CLUSTYPE', axis=1, inplace=True)
    data.drop('ZIP_CODE', axis=1, inplace=True)

    # 3、K_means进行聚类
    K_means_label = k_means(data, 2, predict_path)
    data['k_means'] = K_means_label

    y = np.array(data.RESP)
    data.drop("RESP", axis=1, inplace=True)  # 删除不需要的列
    X = np.array(data)
    print("训练和原始测试数据的大小：{}".format(X.shape))


    DecisionTreeModel = joblib.load((BASE_DIR + "/source/TreeModel.pkl").replace('\\', '/'))
    y_predict = DecisionTreeModel.predict(X)
    accuracy = accuracy_score(y_predict, y)
    print(accuracy)

    # 将预测结果添加到xlsx文件的最后一列
    data_to_append = []

    for i in range(data.shape[0]):
        data_to_append.append(y_predict[i])
    data['predict'] = data_to_append
    data.to_excel(predict_path)  # 保存文件

    c = Counter(data_to_append)
    Countings = [c[0], c[1]] #0和1的个数
    # c = Counter(data_to_append)
    # Counting = [c[0], c[1], c[2], c[3]]     # 此数据可以制作饼图，代表预测结果中各类的比例

    # Dict = {"Info": Info, "Counting": Counting}
    return Countings


def save_back_file(f):
    filename = f.name
    filename = filename.split('.')[0] + '_bk' + '.xlsx'
    save_path = '%s\%s' % (settings.MEDIA_ROOT, filename)
    with open(save_path, 'wb') as file:
        for chunk in f.chunks():
            file.write(chunk)
    return save_path


def recommend(SpecificContent, path=FILE_PATH):

    print("recommand!")
    figure_list = []
    for key, value in SpecificContent.items():
        figure_list.append(eval(value))
    figure_list = figure_list[-15:]      # 每个种类的推荐数量
    print(figure_list)
    print("figure_list")

    ID = SpecificContent['HHKEY']
    fig_need = []
    emmuate = {0: '毛衣', 1: '针织上衣', 2: '针织连衣裙', 3: '女士衬衫', 4: '夹克', 5: '西裤', 6: '休闲裤',
               7: '男士衬衫', 8: '西服', 9: '外套', 10: '时装', 11: '鞋袜', 12: '收藏品', 13: '连衣裙', 14: '珠宝'}

    fig_dir = '../static/img/推荐商品图片集'
    for i in range(len(figure_list)):
        for j in range(int(figure_list[i])):
            fig_need += [fig_dir + '/{}/{}.jpg'.format(emmuate[i], j + 1)]
    print(fig_need)
    return fig_need


def makewordcloud(SpecificContent, filename = FILE_PATH):
    # save_path = filename.split('_')[0] + "_词云" + ".png"
    save_path = "wordcloud_temp.png"
    # TODO
    # import pandas as pd

    # nf = open(r"C:\Users\wjh776a68\Documents\tencent files\2977295009\FileRecv\tmper.txt","w")
    try:
        print("filename")
        print(FILE_PATH)
        data = pd.read_excel(FILE_PATH)

    except:
        print("error243")
        return -1
    """try:
        resultneed = data[data.HHKEY == int(userid)]

        print(resultneed)
    except:
        print(userid)
        print(type(userid))
        print("error252")
        return -1"""

    resultneed = SpecificContent;
    print(resultneed)
    print(resultneed["HHKEY"])



    #print(resultneed.FRE.item())
    label = str()


    if float(resultneed["AMSPEND"]) > data["AMSPEND"].astype('float').sort_values(ascending = False).iloc[int(len(data) * 0.8)]:
        print("AM特许经营权高消费用户")
        label = label + "AM特许经营权高消费用户" + " "



    if float(resultneed["PSSPEND"]) > data["PSSPEND"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["PSSPEND"].mean():
        print("PS专营权高消费用户")
        label = label + "PS专营权高消费用户" + " "


    if float(resultneed["CCSPEND"]) > data["CCSPEND"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["CCSPEND"].mean():
        print("CC专营权高消费用户")
        label = label + "CC专营权高消费用户" + " "


    if float(resultneed["AXSPEND"]) > data["AXSPEND"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["AXSPEND"].mean():
        print("AX特许专营权高消费用户")
        label = label + "AX特许专营权高消费用户" + " "

    if float(resultneed["REC"]) > data["REC"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["REC"].mean():
        print("忠实顾客")
        label = label + "忠实顾客" + " "

    if float(resultneed["STYLES"]) > data["STYLES"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["STYLES"].mean():
        print("购物达人")
        label = label + "购物达人" + " "

    if int(resultneed["WEB"]) == 1:
        print("网络购物者")

        label = label + "网络购物者" + " "

    if float(resultneed["PJEWELRY"]) > data["PJEWELRY"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["PJEWELRY"].mean():
        print("奢侈品爱好者")
        label = label + "奢侈品爱好者" + " "


    if float(resultneed["PFASHION"]) > data["PFASHION"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["PFASHION"].mean():
        print("时尚达人")
        label = label + "时尚达人" + " "

    if float(resultneed["PLEGWEAR"]) > data["PLEGWEAR"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["PLEGWEAR"].mean():
        print("袜子消费大户")
        label = label + "袜子消费大户" + " "


    if float(resultneed["PCOLLSPND"]) > data["PCOLLSPND"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["PCOLLSPND"].mean():
        print("收藏达人")
        label = label + "收藏达人" + " "

    if float(resultneed["PSWEATERS"]) > data["PSWEATERS"].sort_values(ascending = False).iloc[int(len(data) * 0.8)]:#data["PSWEATERS"].mean():
        print("毛衣消费大户")
        label = label + "毛衣消费大户" + " "

    if float(resultneed["PKNIT_TOPS"]) + float(resultneed["PKNIT_DRES"]) > (data["PKNIT_TOPS"] + data["PKNIT_DRES"]).sort_values(ascending = False).iloc[int(len(data) * 0.8)]:
        print("针织品消费大户")
        label = label + "针织品消费大户" + " "

    if float(resultneed["PJACKETS"]) + float(resultneed["PCAS_PNTS"]) + float(resultneed["PSHIRTS"]) > (data["PJACKETS"] + data["PCAS_PNTS"] + data["PSHIRTS"]).sort_values(ascending = False).iloc[int(len(data) * 0.8)]:
        print("休闲服消费大户")
        label = label + "休闲服消费大户" + " "


    if float(resultneed["PCAR_PNTS"]) + float(resultneed["PSUITS"]) + float(resultneed["POUTERWEAR"]) > (data["PCAR_PNTS"] + data["PSUITS"] + data["POUTERWEAR"]).sort_values(ascending = False).iloc[int(len(data) * 0.8)]:
        print("正装消费大户")
        label = label + "正装消费大户" + " "

    if float(resultneed["PBLOUSES"]) + float(resultneed["PKNIT_DRES"]) + float(resultneed["PDRESSES"]) > (data["PBLOUSES"] + data["PKNIT_DRES"] + data["PDRESSES"]).sort_values(ascending = False).iloc[int(len(data) * 0.8)]:
        print("女装消费大户")
        label = label + "女装消费大户" + " "


    #import sys
    #print(sys.argv[0])

    # f = open(u'txt/file.txt','r').read()
    fig = plt.figure(1, figsize=(18, 13))
    ax1 = fig.add_subplot(2, 1, 1)
    # 5wordcloud = WordCloud(background_color="white",width=1000, height=860, margin=2).generate(f)
    font = r'C:\Windows\Fonts\simfang.ttf'
    mask = np.array(image.open(r".\predict\static\img\protrait.png"))

    wordcloud = WordCloud(width=1000, height=300,
                          max_words=1628, relative_scaling=1,
                          font_path=font,
                          mask=mask,
                          repeat=True,
                          background_color='#FFFFFF',
                          normalize_plurals=False)
    wordcloud.generate(label)
    ax1.imshow(wordcloud, interpolation="bilinear")
    ax1.axis('off')
    wordcloud.to_file(save_path)

    with open(save_path, 'rb') as f:
        image_data = f.read()
        save_pathdate_base64 = base64.b64encode(image_data)

    print("云词制作完成")
    return save_pathdate_base64

def upload_file(request):
    global FILE_PATH
    print("hello upload!")
    predictings = []
    if 'input_file' in request.session:
        FILE_PATH = request.session['input_file']

    predict_filename = None
    messages.get_messages(request)
    if request.method == 'POST':
        if request.FILES.get('xlsx') is not None:
            file = request.FILES.get('xlsx')
            filename = file.name
            print(filename)
            FILE_PATH = save_back_file(file)
            print(FILE_PATH)
            request.session['input_file'] = FILE_PATH
            messages.add_message(request, messages.SUCCESS, "文件上传成功")
        else:
            messages.add_message(request, messages.WARNING, "文件上传失败")

    else:
        pass

    print(len(predictings))
    #return HttpResponse("done")
    return render(request, 'upload_file.html',locals())

def predict_file(request):

    print("hello index!")
    predictings = []
    #predictings = predict(FILE_PATH)
    predictings = [13,42]
    messages.add_message(request, messages.SUCCESS, "预测成功")


    return HttpResponse(str(predictings[0]) + " " + str(predictings[1]))
    #return render(request, 'index.html', {"predictings": predictings})

@login_required(login_url=settings.LOGIN_URL)
def index(request):
    global FILE_PATH
    print("hello index!")
    predictings = []
    if 'input_file' in request.session:
        FILE_PATH = request.session['input_file']
    # else:
    #    FILE_PATH = None
    predict_filename = None
    messages.get_messages(request)
    if request.method == 'POST':
        if 'input_file' in request.POST:
            if request.FILES.get('xlsx') is not None:
                file = request.FILES.get('xlsx')
                filename = file.name
                print(filename)
                FILE_PATH = save_back_file(file)
                print(FILE_PATH)
                request.session['input_file'] = FILE_PATH
                messages.add_message(request, messages.SUCCESS, "文件上传成功")
            else:
                messages.add_message(request, messages.WARNING, "文件上传失败")
        if 'predict' in request.POST:
            predictings = predict(FILE_PATH)
            messages.add_message(request, messages.SUCCESS, "预测成功")
    else:
        pass
    # print("Counting....")
    # print(Counting)
    # Counting = [21, 29, 50]
    # Dict = {"Info": Info, "Counting": Counting}
    print(len(predictings))
    return render(request, 'index.html', locals())
    #return render(request, 'index.html', {"predictings": predictings})


def icon(request):

    return render(request, 'icons.html', locals())


def maps(request):
    return render(request, 'maps.html', locals())


def notifications(request):
    return render(request, 'notifications.html', locals())

@login_required(login_url=settings.LOGIN_URL)
def table(request):
    return render(request, 'table.html', locals())


def cloud(request):
    income = request.POST.get('SpecificContent')
    SpecificContent = json.loads(income)
    #return
   # print(type(request.POST.dict()))
    #income = request.POST.dict()
    #print(income)
   # ID = income["ID"]  #得到ID
    #print(ID)

    save_pathdate_base64 = makewordcloud(SpecificContent) # , FILE_PATH)
    print("finishedcloud")
    return HttpResponse(save_pathdate_base64)


def item_recommend(request):
    income = request.POST.get('SpecificContent')
    SpecificContent = json.loads(income)
    figure_list = recommend(SpecificContent)
    print(figure_list)
    return HttpResponse(figure_list)


def sender_mail(request):
    print('111111111111111111111111')
    smt_p = smtplib.SMTP()
    smt_p.connect(host='smtp.qq.com', port=25)
    sender, password = '2927354611@qq.com', "wluqpodglrwpddfh"
    # sender是发送者邮箱地址  后面是对应的SMTP的代码
    smt_p.login(sender, password)
    receiver_addresses, count_num = [
        '2977295009@qq.com', '1066957378@qq.com', 'wanghaitao11291022@foxmail.com'], 1
    for email_address in receiver_addresses:
        try:
            msg = multipart.MIMEMultipart()
            msg['From'] = "zhenguo"
            msg['To'] = email_address
            msg['subject'] = header.Header('这是邮件主题通知', 'utf-8')
            msg.attach(text.MIMEText(
                '这是一封测试邮件，请勿回复本邮件~', 'plain', 'utf-8'))
            smt_p.sendmail(sender, email_address, msg.as_string())
            time.sleep(10)
            print('第%d次发送给%s' % (count_num, email_address))
            count_num = count_num + 1
        except Exception as e:
            print('第%d次给%s发送邮件异常' % (count_num, email_address))
            continue
        # smt_p.quit()
    return HttpResponse()


def template(request):
    return render(request, 'template.html', locals())


def typography(request):
    return render(request, 'typography.html', locals())


def upgrade(request):
    return render(request, 'upgrade.html', locals())


def account(request):
    return render(request, 'account.html', locals())


def start(request):
    #print("Starting!!!!!!!")
    return render(request, 'start.html', locals())


def signup(request):
    state = None
    if request.method == 'POST':
        password = request.POST.get('password')
        repeat_password = request.POST.get('repeat_password')
        #email = request.POST.get('email')
        username = request.POST.get('username')
        #print(password)
       # print(repeat_password)
        if password != repeat_password:
            state = 'passwordunpair'
            #return HttpResponse(state)

        elif User.objects.filter(username=username):
            state = 'usernameexist'
            #return HttpResponse(state)
        else:
            #new_user = User.Objects.create_user(username=username, password=password)
            new_user = User.objects.create_user(username=username, password=password)
            new_user.save()
            state = 'signupsuccess'

        return HttpResponse(state)

    return render(request, 'signup.html', locals())


def login_c(request):
    #print("checkpoint")
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        #user = User.objects.filter(username=username)
        user = authenticate(username=username, password=password)

        if user is not None:
            #print(user[0].password)
            #if user[0].password == password:

                #request.session['username'] = username
            login(request, user)
                #user = authenticate(username=username, password=password)
            return HttpResponse('loginsuccess')
        else:
            return HttpResponse('passwordunpair')
        #else:
        #    return HttpResponse('usernotexist')

    return render(request, 'login.html', locals())



def logoutuser(request):

    logout(request)

    return HttpResponse("logoutsuccess")
    # Redirect to a success page.
    ...